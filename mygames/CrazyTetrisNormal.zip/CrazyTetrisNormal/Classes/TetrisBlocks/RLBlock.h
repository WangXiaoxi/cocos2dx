//
//  RLBlock.h
//  CrazyTetris
//
//  Created by nyist-mac1 on 15/4/8.
//
//

#ifndef __CrazyTetris__RLBlock__
#define __CrazyTetris__RLBlock__
//反L型方块
#include <stdio.h>
#include "Block.h"

class RLBlock : public Block
{
    
public:
    CREATE_FUNC(RLBlock);
    
};

#endif /* defined(__CrazyTetris__RLBlock__) */
