//
//  LBlock.h
//  CrazyTetris
//
//  Created by nyist-mac1 on 15/4/8.
//
//

#ifndef __CrazyTetris__LBlock__
#define __CrazyTetris__LBlock__
//L型方块
#include <stdio.h>
#include "Block.h"

class LBlock : public Block
{
    
    
public:
    CREATE_FUNC(LBlock);
};

#endif /* defined(__CrazyTetris__LBlock__) */
