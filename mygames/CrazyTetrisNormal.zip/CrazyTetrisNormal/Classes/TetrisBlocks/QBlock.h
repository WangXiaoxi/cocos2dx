//
//  QBlock.h
//  CrazyTetris
//
//  Created by nyist-mac1 on 15/4/8.
//
//

#ifndef __CrazyTetris__QBlock__
#define __CrazyTetris__QBlock__
//田字形，正方形方块
#include <stdio.h>
#include "Block.h"

class QBlock : Block {
    
public:
    
    CREATE_FUNC(QBlock);
};

#endif /* defined(__CrazyTetris__QBlock__) */
