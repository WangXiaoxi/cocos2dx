//
//  RZBlock.h
//  CrazyTetris
//
//  Created by nyist-mac1 on 15/4/8.
//
//

#ifndef __CrazyTetris__RZBlock__
#define __CrazyTetris__RZBlock__
//反Z型方块
#include <stdio.h>
#include "Block.h"

class RZBlock : public Block
{

public:
    CREATE_FUNC(RZBlock);
};
#endif /* defined(__CrazyTetris__RZBlock__) */
